#pragma once
#include "stdafx.h"

LRESULT CALLBACK HomeWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void CreateAndShowWindow_Home(HWND);