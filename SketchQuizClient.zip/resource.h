//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// PrjClient.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDC_ISIPV6                      1001
#define IDC_ISUDP                       1002
#define IDC_IPADDR                      1003
#define IDC_PORT                        1004
#define IDC_CONNECT                     1005
#define IDC_SENDMSG                     1006
#define IDC_MSG                         1007
#define IDC_STATUS                      1008
#define IDC_ERASEPIC                    1009
#define IDC_COLORRED                    1010
#define IDC_COLORGREEN                  1011
#define IDC_COLORBLUE                   1012
#define IDC_SENDFILE                    1013
#define IDC_DUMMY                       1014

// =========== ���� ===========
#define IDC_PENCOLOR                    3100
#define IDC_LINEWIDTH                   3101

// =========== ��ȣ ===========
#define IDC_FIGURE                      4100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
