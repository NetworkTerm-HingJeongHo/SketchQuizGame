#pragma once
#include "stdafx.h"

void CreateAndShowWindow_Login(HWND);
LRESULT CALLBACK LoginWndProc(HWND hwndLogin, UINT msg, WPARAM wParam, LPARAM lParam);